
cd
cd ..
sudo cp -r /home/*/sunrise/vsim /home/*/intelFPGA_lite/18.1/modelsim_ase/bin

sudo apt-get build-dep -a i386 libfreetype6
sudo dpkg --add-architecture i386
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install build-essential




#sudo apt-get install dpkg-dev  
#sudo apt-get remove libpng12-0:amd64
#sudo dpkg -i install /home/*/sunrise/libpng12-0_1.2.54-1ubuntu1.1_i386.deb


sudo apt-get install gcc-multilib g++-multilib \
lib32z1 lib32stdc++6 lib32gcc1 \
expat:i386 fontconfig:i386 libfreetype6:i386 libexpat1:i386 libc6:i386 libgtk-3-0:i386 \
libcanberra0:i386 libpng12-0:i386 libice6:i386 libsm6:i386 libncurses5:i386 zlib1g:i386 \
libx11-6:i386 libxau6:i386 libxdmcp6:i386 libxext6:i386 libxft2:i386 libxrender1:i386 \
libxt6:i386 libxtst6:i386

sudo apt-get install --reinstall gcc-multilib g++-multilib lib32z1 lib32stdc++6 lib32gcc1 expat:i386 fontconfig:i386 libfreetype6:i386 libexpat1:i386 libc6:i386 libgtk-3-0:i386 libcanberra0:i386 libpng12-0:i386 libice6:i386 libsm6:i386 libncurses5:i386 zlib1g:i386 libx11-6:i386 libxau6:i386 libxdmcp6:i386 libxext6:i386 libxft2:i386 libxrender1:i386 libxt6:i386 libxtst6:i386



sudo apt-get install --reinstall build-essential
sudo apt-get install --reinstall gcc
sudo dpkg-reconfigure build-essential
sudo dpkg-reconfigure gcc


cd
cd /home/*/sunrise/freetype-2.4.12  

./configure --build=i686-pc-linux-gnu "CFLAGS=-m32" "CXXFLAGS=-m32" "LDFLAGS=-m32"  

make clean
make
make clean -j8
make –j8 

cd ..
cd /home/*/intelFPGA_lite/18.1/modelsim_ase/
mkdir lib32
cd ..
sudo cp /home/*/sunrise/freetype-2.4.12/objs/.libs/libfreetype.so* /home/*/intelFPGA_lite/18.1/modelsim_ase/lib32 

cd /home/ahmed/intelFPGA_lite/18.1/modelsim_ase/bin
echo starting
./vsim



 
